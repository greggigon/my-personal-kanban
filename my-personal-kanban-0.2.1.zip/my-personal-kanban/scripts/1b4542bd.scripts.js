'use strict';
function Kanban(name, numberOfColumns) {
  return {
    name: name,
    numberOfColumns: numberOfColumns,
    columns: []
  };
}
function KanbanColumn(name) {
  return {
    name: name,
    cards: []
  };
}
function KanbanCard(name, details, color) {
  this.name = name;
  this.details = details;
  this.color = color;
  return this;
}
'use strict';
angular.module('mpk', ['ui.bootstrap']);
'use strict';
angular.module('mpk').factory('kanbanRepository', function () {
  return {
    kanbansByName: {},
    lastUsed: '',
    add: function (kanban) {
      this.kanbansByName[kanban.name] = kanban;
      this.save();
      return kanban;
    },
    all: function () {
      return this.kanbansByName;
    },
    get: function (kanbanName) {
      return this.kanbansByName[kanbanName];
    },
    remove: function (kanbanName) {
      if (this.kanbansByName[kanbanName]) {
        delete this.kanbansByName[kanbanName];
      }
      return this.kanbansByName;
    },
    save: function () {
      localStorage.setItem('myPersonalKanban', angular.toJson({
        kanbans: this.kanbansByName,
        lastUsed: this.lastUsed
      }, false));
      return this.kanbansByName;
    },
    load: function () {
      var saved = angular.fromJson(localStorage.getItem('myPersonalKanban'));
      if (saved === null) {
        return null;
      }
      this.kanbansByName = saved.kanbans;
      this.lastUsed = saved.lastUsed;
      return this.kanbansByName;
    },
    getLastUsed: function () {
      if (!this.lastUsed) {
        return this.kanbansByName[Object.keys(this.kanbansByName)[0]];
      }
      return this.kanbansByName[this.lastUsed];
    },
    setLastUsed: function (kanbanName) {
      this.lastUsed = kanbanName;
      return this.lastUsed;
    }
  };
});
'use strict';
angular.module('mpk').factory('kanbanManipulator', function () {
  return {
    addColumn: function (kanban, columnName) {
      kanban.columns.push(new KanbanColumn(columnName));
    },
    addCardToColumn: function (kanban, column, cardTitle, details, color) {
      angular.forEach(kanban.columns, function (col) {
        if (col.name === column.name) {
          col.cards.push(new KanbanCard(cardTitle, details, color));
        }
      });
    },
    removeCardFromColumn: function (kanban, column, card) {
      angular.forEach(kanban.columns, function (col) {
        if (col.name === column.name) {
          col.cards.splice(col.cards.indexOf(card), 1);
        }
      });
    }
  };
});
'use strict';
var ApplicationController = function ($scope, $window, kanbanRepository) {
  $scope.colorOptions = [
    'FFFFFF',
    'DBDBDB',
    'FFB5B5',
    'FF9E9E',
    'FCC7FC',
    'FC9AFB',
    'CCD0FC',
    '989FFA',
    'CFFAFC',
    '9EFAFF',
    '94D6FF',
    'C1F7C2',
    'A2FCA3',
    'FAFCD2',
    'FAFFA1',
    'FCE4D4',
    'FCC19D'
  ];
  $scope.$on('ChangeCurrentKanban', function () {
    $scope.kanban = kanbanRepository.getLastUsed();
    $scope.allKanbans = Object.keys(kanbanRepository.all());
    $scope.selectedToOpen = $scope.kanban.name;
  });
  $scope.$on('Open', function (event, args) {
    $scope.kanban = kanbanRepository.get(args.kanbanName);
    kanbanRepository.setLastUsed(args.kanbanName);
    kanbanRepository.save();
  });
  $scope.$on('KanbanDeleted', function () {
    $scope.kanban = undefined;
    $scope.allKanbans = Object.keys(kanbanRepository.all());
  });
  var currentKanban = new Kanban('Kanban name', 0);
  var loadedRepo = kanbanRepository.load();
  if (loadedRepo && kanbanRepository.getLastUsed() != undefined) {
    currentKanban = kanbanRepository.getLastUsed();
  }
  $scope.kanban = currentKanban;
  $scope.allKanbans = Object.keys(kanbanRepository.all());
  $scope.selectedToOpen = currentKanban.name;
  $scope.$watch('kanban', function () {
    kanbanRepository.save();
  }, true);
  var windowHeight = angular.element($window).height() - 180;
  $scope.minHeightOfColumn = 'min-height:' + windowHeight + 'px;';
  $scope.triggerOpen = function () {
    $scope.$broadcast('TriggerOpenKanban');
  };
};
'use strict';
var MenuController = function ($scope, kanbanRepository, $modal) {
  $scope.newKanban = function () {
    var modalInstance = $modal.open({
        templateUrl: 'NewKanbanModal.html',
        controller: 'NewKanbanController'
      });
    modalInstance.result.then(function (created) {
      if (created) {
        $scope.$emit('ChangeCurrentKanban');
      }
    });
  };
  $scope.openKanban = function () {
    var modalInstance = $modal.open({
        templateUrl: 'OpenKanban.html',
        controller: 'OpenKanbanController',
        resolve: {
          allKanbans: function () {
            return $scope.allKanbans;
          },
          currentKanban: function () {
            return $scope.kanban;
          }
        }
      });
    modalInstance.result.then(function (toOpen) {
      if (toOpen) {
        $scope.$emit('Open', { kanbanName: toOpen });
      }
    });
  };
  $scope.delete = function () {
    if (confirm('You sure you want to delete the entire Kanban?')) {
      kanbanRepository.remove($scope.kanban.name);
      var all = kanbanRepository.all();
      var names = Object.keys(all);
      if (names.length > 0) {
        kanbanRepository.setLastUsed(names[0]);
      } else {
        kanbanRepository.setLastUsed(undefined);
      }
      $scope.$emit('KanbanDeleted');
      $scope.openKanban();
    }
    return false;
  };
  $scope.$on('TriggerOpen', function () {
    $scope.openKanban();
  });
};
'use strict';
var NewKanbanController = function ($scope, $modalInstance, kanbanRepository, kanbanManipulator) {
  $scope.numberOfColumns = 3;
  $scope.kanbanName = '';
  $scope.createNew = function () {
    if (!this.newKanbanForm.$valid) {
      return false;
    }
    var newKanban = new Kanban(this.kanbanName, this.numberOfColumns);
    for (var i = 1; i < parseInt(this.numberOfColumns) + 1; i++) {
      kanbanManipulator.addColumn(newKanban, 'Column ' + i);
    }
    kanbanRepository.add(newKanban);
    this.kanbanName = '';
    this.numberOfColumns = 3;
    kanbanRepository.setLastUsed(newKanban.name);
    $modalInstance.close(true);
    return true;
  };
  $scope.closeNewKanban = function () {
    $scope.numberOfColumns = 3;
    $scope.kanbanName = '';
    $modalInstance.close();
  };
};
'use strict';
var OpenKanbanController = function ($scope, $modalInstance, allKanbans, currentKanban) {
  $scope.allKanbans = allKanbans;
  $scope.selectedToOpen = currentKanban ? currentKanban.name : undefined;
  $scope.close = function () {
    $modalInstance.close();
  };
  $scope.open = function () {
    if (!this.openKanbanForm.$valid) {
      return false;
    }
    $modalInstance.close(this.selectedToOpen);
    return true;
  };
};
'use strict';
var CardController = function ($scope, $modalInstance, colorOptions, card) {
  function initScope(scope, card, colorOptions) {
    scope.name = card.name;
    scope.details = card.details;
    scope.card = card;
    scope.cardColor = card.color;
    scope.colorOptions = colorOptions;
  }
  $scope.close = function () {
    $modalInstance.close();
  };
  $scope.update = function () {
    if (!this.cardDetails.$valid) {
      return false;
    }
    this.card.name = this.name;
    this.card.details = this.details;
    this.card.color = this.cardColor;
    $modalInstance.close(this.card);
  };
  initScope($scope, card, colorOptions);
};
'use strict';
var NewKanbanCardController = function ($scope, $modalInstance, kanbanManipulator, colorOptions, column) {
  function initScope(scope, colorOptions) {
    scope.kanbanColumnName = column.name;
    scope.column = column;
    scope.title = '';
    scope.details = '';
    scope.cardColor = colorOptions[0];
    scope.colorOptions = colorOptions;
  }
  $scope.addNewCard = function () {
    if (!this.newCardForm.$valid) {
      return false;
    }
    $modalInstance.close({
      title: this.title,
      column: column,
      details: this.details,
      color: this.cardColor
    });
  };
  $scope.close = function () {
    $modalInstance.close();
  };
  initScope($scope, colorOptions);
};
'use strict';
var KanbanController = function ($scope, $modal, kanbanManipulator) {
  $scope.addNewCard = function (column) {
    var modalInstance = $modal.open({
        templateUrl: 'NewKanbanCard.html',
        controller: 'NewKanbanCardController',
        resolve: {
          colorOptions: function () {
            return $scope.colorOptions;
          },
          column: function () {
            return column;
          }
        }
      });
    modalInstance.result.then(function (cardDetails) {
      if (cardDetails) {
        kanbanManipulator.addCardToColumn($scope.kanban, cardDetails.column, cardDetails.title, cardDetails.details, cardDetails.color);
      }
    });
  };
  $scope.delete = function (card, column) {
    if (confirm('You sure?')) {
      kanbanManipulator.removeCardFromColumn($scope.kanban, column, card);
    }
  };
  $scope.openCardDetails = function (card) {
    $modal.open({
      templateUrl: 'OpenCard.html',
      controller: 'CardController',
      resolve: {
        colorOptions: function () {
          return $scope.colorOptions;
        },
        card: function () {
          return card;
        }
      }
    });
  };
  $scope.details = function (card) {
    if (card.details !== undefined && card.details !== '') {
      return card.details;
    }
    return card.name;
  };
  $scope.colorFor = function (card) {
    return card.color !== undefined && card.color !== '' ? card.color : $scope.colorOptions[0];
  };
};
'use strict';
angular.module('mpk').directive('colorSelector', function () {
  return {
    restrict: 'E',
    scope: {
      options: '=',
      model: '=ngModel',
      prefix: '@',
      showRadios: '=',
      showHexCode: '='
    },
    require: 'ngModel',
    template: '<span ng-show="showHexCode">&nbsp;#{{model}}</span><div class="pull-left" ng-repeat="option in options" ng-model="option">\n' + '\t<label class="colorBox" for="{{prefix}}{{option}}" ng-class="{selected: option == model}" style="background-color: #{{option}};" ng-click="selectColor(option)"></label>\n' + '\t<br ng-show="showRadios"/>\n' + '\t<input type="radio" id="{{prefix}}{{option}}" name="{{prefix}}" value="{{option}}" ng-show="showRadios" ng-model="model"/>\n' + '</div>\n',
    link: function (scope) {
      if (scope.model === undefined || scope.model === '') {
        scope.model = scope.options[0];
      }
      scope.selectColor = function (color) {
        scope.model = color;
      };
    }
  };
});
'use strict';
angular.module('mpk').directive('focusMe', [
  '$timeout',
  function ($timeout) {
    return {
      link: function (scope, element, attrs) {
        if (attrs.focusMe) {
          scope.$watch(attrs.focusMe, function (value) {
            if (value === true) {
              $timeout(function () {
                element[0].focus();
              });
            }
          });
        } else {
          $timeout(function () {
            element[0].focus();
          });
        }
      }
    };
  }
]);
'use strict';
angular.module('mpk').directive('sortable', function () {
  return {
    restrict: 'A',
    require: '?ngModel',
    link: function (scope, element, attrs, ngModel) {
      if (ngModel) {
        ngModel.$render = function () {
          element.sortable('refresh');
        };
      }
      element.sortable({
        connectWith: attrs.sortableSelector,
        revert: true,
        cancel: 'a',
        remove: function (e, ui) {
          if (ngModel.$modelValue.length === 1) {
            ui.item.sortable.moved = ngModel.$modelValue.splice(0, 1)[0];
          } else {
            ui.item.sortable.moved = ngModel.$modelValue.splice(ui.item.sortable.index, 1)[0];
          }
        },
        receive: function (e, ui) {
          ui.item.sortable.relocate = true;
          ngModel.$modelValue.splice(ui.item.index(), 0, ui.item.sortable.moved);
        },
        update: function (e, ui) {
          ui.item.sortable.resort = ngModel;
        },
        start: function (e, ui) {
          ui.item.sortable = {
            index: ui.item.index(),
            resort: ngModel
          };
        },
        stop: function (e, ui) {
          if (ui.item.sortable.resort && !ui.item.sortable.relocate) {
            var end, start;
            start = ui.item.sortable.index;
            end = ui.item.index();
            ui.item.sortable.resort.$modelValue.splice(end, 0, ui.item.sortable.resort.$modelValue.splice(start, 1)[0]);
          }
          if (ui.item.sortable.resort || ui.item.sortable.relocate) {
            scope.$apply();
          }
        }
      });
    }
  };
});